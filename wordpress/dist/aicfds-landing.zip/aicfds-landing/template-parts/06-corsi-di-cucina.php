<?php
/**
 * Sezione: Corsi di cucina
 * Generato da src/sections/06-corsi-di-cucina.html con wordpress/build.py.
 *
 * @package aicfds-landing
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="aicfds-project" id="corsi-cucina" aria-labelledby="p3-title">
  <div class="aicfds-container">
    <header class="aicfds-project__head">
      <span class="aicfds-project__num" aria-hidden="true">03</span>
      <div>
        <h2 id="p3-title">Corsi di cucina senza glutine</h2>
        <ul class="aicfds-tags" aria-label="Associazioni coinvolte">
          <li>Sardegna</li><li>Calabria</li><li>Fruibili da tutte le regioni</li>
        </ul>
      </div>
    </header>

    <div class="aicfds-split aicfds-split--even">
      <div class="aicfds-split__main">
        <p class="aicfds-lead">
          Corsi online con chef e food blogger per cucinare senza glutine in sicurezza, con più varietà e con
          più gusto. Sono organizzati da AIC Sardegna e AIC Calabria e aperti anche ai celiaci delle altre regioni.
        </p>
        <p>
          I corsi rafforzano l'autonomia in cucina, la sicurezza nella preparazione dei pasti e la varietà
          della dieta, e sono anche un'occasione di socialità da condividere con amici e familiari.
        </p>

        <h3 class="aicfds-h-small">AIC Sardegna — calendario 2026</h3>
        <p class="aicfds-note">Corsi online il sabato, riservati ai soci e aderenti AFC.</p>
        <ul class="aicfds-events">
          <li class="aicfds-event" data-date="2026-01-24">
            <time datetime="2026-01-24"><span>24</span> gen 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">Uno chef per Gaia</p><p class="aicfds-event__meta">con Ilaria Bertinelli</p></div>
          </li>
          <li class="aicfds-event" data-date="2026-03-28">
            <time datetime="2026-03-28"><span>28</span> mar 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">Pasticcerando senza glutine</p><p class="aicfds-event__meta">con Silvia Visconti</p></div>
          </li>
          <li class="aicfds-event" data-date="2026-05-09">
            <time datetime="2026-05-09"><span>9</span> mag 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">La Cassata Celiaca</p><p class="aicfds-event__meta">con Sonia Mancuso</p></div>
          </li>
          <li class="aicfds-event" data-date="2026-09-26">
            <time datetime="2026-09-26"><span>26</span> set 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">Stefania cucina senza glutine</p><p class="aicfds-event__meta">con Stefania Scanu</p></div>
          </li>
          <li class="aicfds-event" data-date="2026-10-24">
            <time datetime="2026-10-24"><span>24</span> ott 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">La Cassata Celiaca</p><p class="aicfds-event__meta">con Sonia Mancuso</p></div>
          </li>
          <li class="aicfds-event" data-date="2026-11-28">
            <time datetime="2026-11-28"><span>28</span> nov 2026</time>
            <div class="aicfds-event__body"><p class="aicfds-event__title">Pasticcerando senza glutine</p><p class="aicfds-event__meta">con Silvia Visconti</p></div>
          </li>
        </ul>
        <p>
          <a class="aicfds-link-ext" href="https://sardegna.celiachia.it/" target="_blank" rel="noopener">
            Info e iscrizioni su AIC Sardegna<span class="aicfds-visually-hidden"> (si apre in una nuova scheda)</span>
            <svg class="aicfds-icon-ext" aria-hidden="true" viewBox="0 0 16 16"><path d="M6 3h7v7M13 3 5.5 10.5M11 9.5V13H3V5h3.5"/></svg>
          </a>
          <span class="aicfds-tbc">link pagina corsi da confermare</span>
        </p>
      </div>

      <div class="aicfds-split__aside aicfds-split__aside--duo">
        <figure class="aicfds-poster">
          <a href="<?php echo esc_url( aicfds_asset( 'img/calendario-corsi-cucina-sardegna-2026.webp' ) ); ?>" target="_blank" rel="noopener">
            <img src="<?php echo esc_url( aicfds_asset( 'img/calendario-corsi-cucina-sardegna-2026.webp' ) ); ?>" width="1080" height="1350" loading="lazy" decoding="async"
                 alt="Locandina AIC Sardegna: calendario 2026 dei corsi di cucina online, con le sei date del sabato elencate a fianco.">
          </a>
          <figcaption>Locandina dei corsi 2026 di AIC Sardegna</figcaption>
        </figure>

        <div class="aicfds-panel aicfds-panel--accent">
          <p class="aicfds-panel__kicker">AIC Calabria</p>
          <h3 class="aicfds-panel__title">Celiaca all'improvviso</h3>
          <p>
            I corsi online di cucina gluten free di AIC Calabria: una parte delle lezioni è realizzata
            nell'ambito di questo progetto.
          </p>
          <a class="aicfds-btn aicfds-btn--primary aicfds-btn--block" href="https://calabria.celiachia.it/i-corsi-online-di-cucina-gluten-free-con-celiaca-allimprovviso/" target="_blank" rel="noopener">
            Scopri i corsi su AIC Calabria<span class="aicfds-visually-hidden"> (si apre in una nuova scheda)</span>
            <svg class="aicfds-icon-ext" aria-hidden="true" viewBox="0 0 16 16"><path d="M6 3h7v7M13 3 5.5 10.5M11 9.5V13H3V5h3.5"/></svg>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
